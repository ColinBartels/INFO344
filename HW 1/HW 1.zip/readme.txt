http://ec2-52-35-44-108.us-west-2.compute.amazonaws.com/

https://github.com/ColinBartels/INFO344/tree/master/HW%201
